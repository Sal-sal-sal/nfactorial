from django import forms
from .models import Lists 

class ListsForm(forms.ModelForm):
    class Meta:
        model = Lists
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={
                'placeholder': 'новый список',
                'class': 'popup-input',
                'style': 'color: aliceblue; font-size: 19px;'
            }),
        }
