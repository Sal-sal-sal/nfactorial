from rest_framework import serializers
from .models import Lists
from api.models import Lists  # Модель списка


class ListsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lists
        fields = ['id','name']


