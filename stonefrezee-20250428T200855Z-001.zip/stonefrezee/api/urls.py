from django.urls import path 
from . import views
urlpatterns = [
    path('', views.get_list , name= 'get_list'), 
    path('post/', views.create_list , name = 'create_list'),
    path('delete_list/<uuid:pk>/', views.delete_list, name='delete_list'),
   
]
