from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404 # get_object_or_404 может использоваться и для Lists
# from django.shortcuts import render, redirect # Эти импорты не нужны, если нет HTML views для Lists
from .models import Lists # Импортируем Lists из текущего приложения
from .serializers import ListsSerializer # Импортируем сериализатор для Lists

# Импорты для Channels (если они используются для List updates)
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

LISTS_GROUP_NAME = 'all_lists_group' # Группа для WebSocket обновлений списков

# --- API View: Создание списка ---
@api_view(['POST'])
def create_list(request):
    serializer = ListsSerializer(data =request.data)
    if serializer.is_valid():
        list_instance = serializer.save()
        # Отправка WS сообщения (код как у тебя)
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            LISTS_GROUP_NAME,
            { 'type': 'list_created', 'list': serializer.data }
        )
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# --- API View: Удаление списка ---
@api_view(['DELETE'])
def delete_list(request, pk):
    try:
        # get_object_or_404 может быть чище, но get() тоже работает
        list_item = get_object_or_404(Lists, pk=pk) # Используем get_object_or_404
        list_id_to_delete = str(list_item.pk) # Преобразуем UUID в строку для WS
        list_item.delete()
        # Отправка WS сообщения (код как у тебя, убедись, что ID строка)
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            LISTS_GROUP_NAME,
            { 'type': 'list_deleted', 'list_id': list_id_to_delete }
        )
        return Response(status=status.HTTP_204_NO_CONTENT)
    except Exception as e: # Ловим более общее исключение, если get_object_or_404 не было использовано
         # get_object_or_404 сам вернет 404, если объект не найден
         # Если используешь .get(), нужно отдельно ловить Lists.DoesNotExist
         if isinstance(e, Lists.DoesNotExist):
              return Response({'error': 'List not found'}, status=status.HTTP_404_NOT_FOUND)
         print(f"Error in delete_list: {e}")
         return Response({"detail": f"An error occurred: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# --- API View: Получение всех списков ---
@api_view(['GET'])
def get_list(request):
    lists = Lists.objects.all()
    serializer = ListsSerializer(lists, many= True)
    return Response(serializer.data)