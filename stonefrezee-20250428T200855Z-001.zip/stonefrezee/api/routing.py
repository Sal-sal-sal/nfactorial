from django.urls import re_path
from . import consumer # Импортируем консьюмеры
# САМАЯ ГЛУПАЯ ОШИБКА В МИРЕ,  в импорте я написал consumer's', а не consumer
#  потом полвека гадал почему сервер не может получить consumer.ListConsumer.as_asgi()
websocket_urlpatterns = [
    # Маршрут для WebSocket соединений, связанных со списками
    re_path(r'ws/lists/$', consumer.ListConsumer.as_asgi()),
    # можно добавить другие маршруты для других нужд
    # re_path(r'ws/chat/(?P<room_name>\w+)/$', consumers.ChatConsumer.as_asgi()),
]