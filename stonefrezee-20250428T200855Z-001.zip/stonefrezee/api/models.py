from django.db import models
import uuid


# Create your models here.
class Lists(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name


class TrashList(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    data = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name
    
