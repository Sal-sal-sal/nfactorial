LISTS_GROUP_NAME = 'all_lists_group'
import json
import uuid
from channels.generic.websocket import AsyncWebsocketConsumer


# Имя группы, в которую будут добавляться все подключения
# связанные с общим списком


class ListConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Присоединение к группе при подключении
        await self.channel_layer.group_add(
            LISTS_GROUP_NAME,
            self.channel_name
        )
        await self.accept()
        print(f"WebSocket connected: {self.channel_name}")

    async def disconnect(self, close_code):
        # Отсоединение от группы при отключении
        print(f"WebSocket disconnected: {self.channel_name}")
        await self.channel_layer.group_discard(
            LISTS_GROUP_NAME,
            self.channel_name
        )

    # --- Методы для отправки сообщений клиентам из группы ---
    # Эти методы будут вызываться, когда из Django view (или другого места)
    # отправляется сообщение в группу LISTS_GROUP_NAME

    async def list_created(self, event):
        """ Отправляет сообщение о создании нового списка клиенту """
        list_data = event['list']

        if 'id' in list_data and isinstance(list_data['id'], uuid.UUID):
            list_data['id'] = str(list_data['id'])
        
        list_id = str(list_data['id']) # json.dumps не умеет работать с uuid печально
        await self.send(text_data=json.dumps({
            'type': 'list_created',
            'list': list_data
            
        }))

    async def list_deleted(self, event):
        """ Отправляет сообщение об удалении списка клиенту """
        
        list_id = str(event['list_id'])
        await self.send(text_data=json.dumps({
            'type': 'list_deleted',
            'list_id': str(list_id)
        }))