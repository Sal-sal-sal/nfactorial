document.addEventListener('DOMContentLoaded', () => {
    let chatWin = document.getElementById('ai-chat-window');
    let msgBox = document.getElementById('chat-messages');
    let inp = document.getElementById('chat-input');
    let sendBtn = document.getElementById('send-chat-button');
    let isBusy = false;
    let botModel= 'deepseek';
    
    const chatExists = chatWin && msgBox && inp && sendBtn;

    function getCookie(name) {
        if (!name) return null;
        
        let cookie = null;
        try {
            if (document.cookie && document.cookie !== '') {
                const cookies = document.cookie.split(';');
                for (let i = 0; i < cookies.length; i++) {
                    const c = cookies[i].trim();
                    if (c.substring(0, name.length + 1) === (name + '=')) {
                        cookie=decodeURIComponent(c.substring(name.length + 1));
                        break;
                    }
                }
            }
        } catch (error) {
            console.error('Проблема с cookie:', error);
        }
        return cookie;
    }
    
    const csrf=getCookie('csrftoken');
    
    async function checkApi(url) {
        try {
            const resp = await fetch(url, {
                method: 'HEAD',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            return resp.ok;
        } catch (error) {
            console.error(`API ${url} недоступен:`, error);
            return false;
        }
    }

    function showPopup() {
        const popup = document.getElementById('about-popup');
        if(popup) popup.classList.add('visible');
    }
    
    function hidePopup() {
        const popup = document.getElementById('about-popup');
        if(popup) popup.classList.remove('visible');
    }

    function addMsg(text, sender, isLoading=false) {
        if (!msgBox) return null;

        const el = document.createElement('div');
        el.classList.add('chat-message', sender);
        el.textContent = text;
        
        if (isLoading) {
            el.classList.add('loading');
        }

        msgBox.appendChild(el);
        msgBox.scrollTop=msgBox.scrollHeight;
        return el;
    }

    function toggleChat() {
        if (!chatExists) {
            console.error("Чат не найден");
            return;
        }
        
        chatWin.classList.toggle('visible');
        
        if (chatWin.classList.contains('visible')) {
            inp.focus();
            
            if (msgBox.childElementCount === 0) {
                addMsg("Привет! Чем я могу помочь?", 'ai');
            }
        }
    }

    async function getKey() {
        try {
            const resp = await fetch('/get-api-key', {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            if (resp.ok) {
                const data = await resp.json();
                return data.apiKey;
            } else {
                console.error('Ошибка получения ключа API.');
                return null;
            }
        } catch (error) {
            console.error('Ошибка ключа:', error);
            return null;
        }
    }

    async function sendMsg() {
        if (!chatExists || isBusy) return;
        
        const text = inp.value.trim();
        if (!text) return;
        
        isBusy = true;
        inp.disabled = true;
        sendBtn.disabled = true;
        
        addMsg(text, 'user');
        inp.value='';
        
        const loadingMsg = addMsg(' Получение ответа...', 'ai', true);
        
        try {
            const apiUrl="https://openrouter.ai/api/v1/chat/completions";
            const apiOk= await checkApi(apiUrl);
            
            if (!apiOk) {
                throw new Error('API OpenRouter недоступен');
            }
            
            const key = await getKey();
            if (!key) {
                throw new Error('Не удалось получить API ключ');
            }
            
            const resp = await fetch(apiUrl, {
                method: "POST",
                headers: {
                    "Authorization": key,
                    "HTTP-Referer": window.location.href,
                    "X-Title": document.title,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    "model": "deepseek/deepseek-v3-base:free",
                    "messages": [
                        {
                            "role": "user",
                            "content": text
                        }
                    ]
                })
            });
            
            if (loadingMsg) loadingMsg.classList.remove('loading');

            if (!resp.ok) {
                const errData = await resp.json().catch(() => ({ detail: `Ошибка: ${resp.status}` }));
                const errText = `Ошибка: ${errData.detail || errData.error || resp.statusText || 'Неизвестная ошибка'}`;
                
                if (loadingMsg) {
                    loadingMsg.textContent=errText;
                    loadingMsg.style.backgroundColor= '#cc3333';
                } else { 
                    addMsg(errText, 'ai'); 
                }
            } else {
                const data= await resp.json();
                const reply = data.choices && data.choices[0]?.message?.content || 
                    "Не удалось получить ответ";
                
                if (loadingMsg) {
                    loadingMsg.textContent=reply;
                } else { 
                    addMsg(reply, 'ai'); 
                }
            }
        } catch (error) {
            console.error('Ошибка сообщения:', error);
            
            if (loadingMsg) {
                loadingMsg.classList.remove('loading');
                loadingMsg.textContent='Ошибка сети при отправке сообщения: ' + error.message;
                loadingMsg.style.backgroundColor='#cc3333';
            } else { 
                addMsg('Ошибка сети при отправке сообщения: ' + error.message, 'ai'); 
            }
        } finally {
            isBusy = false;
            inp.disabled = false;
            sendBtn.disabled = false;
            inp.focus();
        }
    }

    function handleSend() {
        if (!isBusy) {
            sendMsg();
        }
    }

    if (chatExists) {
        sendBtn.addEventListener('click', handleSend);
        inp.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                handleSend();
            }
        });
        
        const askBtn = document.querySelector('.text-div[onclick="toggleChatWindow()"]');
        if (askBtn) {
            askBtn.onclick = null;
            askBtn.addEventListener('click', toggleChat);
        }
        
        if (!csrf) {
            console.error("CSRF токен не найден запросы могут не работать");
            addMsg("Ошибка конфигурации CSRF. Отправка сообщений может быть недоступна.", 'ai');
        }
    } else {
        console.error("Чат не найден");
    }

    
    window.toggleChatWindow = toggleChat;
    window.showAboutPopup= showPopup;
    window.hideAboutPopup = hidePopup;
});