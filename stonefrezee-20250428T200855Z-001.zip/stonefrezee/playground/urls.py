
from . import views
from django.urls import path
# from debug_toolbar import decorators
urlpatterns = [
    path('', views.say_hello, name='say_hello'),

]


#  