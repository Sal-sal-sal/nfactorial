from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest


def say_hello(request):
    return render(request,'c.html')

# Create your views here.
