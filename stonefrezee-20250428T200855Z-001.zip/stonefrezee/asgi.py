"""
ASGI config for stonefrezee project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import api.routing         # Маршруты для главной страницы списков ('ws/lists/')
import product.routing     # <--- ИМПОРТИРУЕМ МАРapplication
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack # Если нужна аутентификация

# Импортируем роутинг ИЗ ОБОИХ приложений, где есть WebSocket
import api.routing       # Маршруты для главной страницы списков
import product.routing   # Маршруты для страницы продуктов списка

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'stonefrezee.settings')

django_asgi_app = get_asgi_application()

application = ProtocolTypeRouter({
    # Обработка стандартных HTTP запросов через Django
    "http": django_asgi_app,

    # Обработка WebSocket соединений
    "websocket": AuthMiddlewareStack( # Обертка для доступа к request.user, если нужно
        URLRouter(
            # --- ОБЪЕДИНЯЕМ СПИСКИ URL-ШАБЛОНОВ ---
            # Сначала идут маршруты из api, потом из product
            api.routing.websocket_urlpatterns +
            product.routing.websocket_urlpatterns
            # ----------------------------------------
        )
    ),
})