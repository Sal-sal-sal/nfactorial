# --- START OF FILE product/urls.py ---
from django.urls import path
from . import views


views.product_detail_page_view
urlpatterns = [
    path('api/lists/<uuid:list_pk>/products/', views.product_list_create_api, name='product-list-create'),
    path('products/<uuid:product_pk>/', views.product_detail_api, name='product-detail'),
    path('view/lists/<uuid:list_pk>/products/', views.product_list_page_view , name='page_list'),
    path('view/products/<uuid:product_pk>/', views.product_detail_page_view, name='page_detail'),
    # path('lists/<uuid:list_pk>/products/<uuid:product_pk>/', views.product_list_update_api, name='product-list-update'),
    # path('lists/<uuid:list_pk>/', views.product_list_page_view, name='product-list-page'),
]