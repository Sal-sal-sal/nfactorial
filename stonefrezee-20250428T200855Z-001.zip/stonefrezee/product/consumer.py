import json
import uuid # нужен для uuid проверок
from channels.generic.websocket import AsyncWebsocketConsumer

class ProductConsumer(AsyncWebsocketConsumer):
    """
    Обрабатывает WebSocket соединения для страницы продуктов конкретного списка
    """
    async def connect(self):
        # берем ID списка из URL
        try:
            # строка UUID в kwargs
            self.list_pk_str = self.scope['url_route']['kwargs']['list_pk']
            # проверяем валидный ли UUID 
            uuid.UUID(self.list_pk_str)
        except (KeyError, ValueError):
            # нету list_pk или плохой UUID
            print(f"ProductConsumer: Invalid list_pk in URL scope: {self.scope['url_route']['kwargs']}")
            await self.close()
            return

        # делаем уникальное имя групы для списка
        self.group_name = f"product_list_{self.list_pk_str}"
        print(f"ProductConsumer connecting to group: {self.group_name}")

        # добавляем канал к группе
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )

        # принимаем соединение
        await self.accept()
        print(f"ProductConsumer WebSocket connected: {self.channel_name} for list {self.list_pk_str}")

    async def disconnect(self, close_code):
        # убераем канал из группы когда соединение закрывается
        if hasattr(self, 'group_name'): # проверим есть ли group_name
            print(f"ProductConsumer disconnecting from group: {self.group_name}")
            await self.channel_layer.group_discard(
                self.group_name,
                self.channel_name
            )
        print(f"ProductConsumer WebSocket disconnected: {self.channel_name}, code: {close_code}")

    # --- Обработчики для сообщений из Django ---

    async def product_created(self, event):
        """ Отправляет клиенту инфу о новом продукте """
        product_data = event['product']
        print(f"Sending product_created event to {self.channel_name}: {product_data}")
        # делаем uuid в строку
        if 'id' in product_data and isinstance(product_data.get('id'), uuid.UUID):
            product_data['id'] = str(product_data['id'])

        # TODO когдато перенести этот код в хелпер
        await self.send(text_data=json.dumps({
            'type': 'product_created',
            'product': product_data
        }))

    async def product_deleted(self, event):
        """ Говорит клиенту что продукт удалён """
        product_id = event['product_id']
        print(f"Sending product_deleted event to {self.channel_name}: {product_id}")
        await self.send(text_data=json.dumps({
            'type': 'product_deleted',
            # ID уже строка после str() в view
            'product_id': product_id
        }))

    async def product_updated(self, event):
        """ Отправляет обновленые данные продукта """
        product_data = event['product']
        print(f"Sending product_updated event to {self.channel_name}: {product_data}")
        # uuid -> строка
        if 'id' in product_data and isinstance(product_data.get('id'), uuid.UUID):
            product_data['id'] = str(product_data['id'])

        await self.send(text_data=json.dumps({
            'type': 'product_updated',
            'product': product_data
        }))

    # Клиент пока ничего не шлёт
    # async def receive(self, text_data):
    #    # потом доделаем