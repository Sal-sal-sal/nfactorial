# --- START OF FILE product/routing.py ---
from django.urls import re_path # Используем re_path для регулярных выражений
from . import consumer # Импортируем наш новый консьюмер

websocket_urlpatterns = [
    # Маршрут для WebSocket соединений страницы продуктов конкретного списка
    # Захватываем UUID списка и передаем его в scope как 'list_pk'
    re_path(r'^ws/lists/(?P<list_pk>[0-9a-f-]+)/products/$', consumer.ProductConsumer.as_asgi()),
]
# --- END OF FILE product/routing.py ---