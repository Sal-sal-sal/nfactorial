from django.shortcuts import render, get_object_or_404,redirect

from rest_framework  import  status
from rest_framework.decorators  import  api_view
from rest_framework.response  import  Response

from api.models  import  Lists
from .models  import  Product
from .serializers  import  ProductSerializer

from channels.layers  import  get_channel_layer
from asgiref.sync  import  async_to_sync


def product_list_page_view(request, list_pk):
    # получаем продукты из базы
    products  =  Product.objects.filter(list_id=list_pk)

    # фильтруем если надо
    category  =  request.GET.get('category')
    if  category:
        products  =  products.filter(category=category)
    
    # берём объект списка  
    list_obj  =  get_object_or_404(Lists,  pk=list_pk)
    
    context  =  {
        'list':  list_obj,
        'products':  products,
    }

    return  render(request, 'product/product_list.html',  context)


def product_detail_page_view(request, product_pk):
    """
    Отображает детальную страницу продукта.
    """
    product = get_object_or_404(Product, pk=product_pk)
    
    # Получаем список продукта
    list_obj = product.list  # может быть None

    context = {
        'product': product,
        'list': list_obj
    }

    return render(request, 'product/product_detail.html', context)

@api_view(['GET', 'POST'])
def product_list_create_api(request, list_pk):
    list_obj  =  get_object_or_404(Lists,  pk=list_pk)
    print(f"List object: {list_obj.id}")    # debug
    if  request.method  ==  'GET':
        #products = list_obj.products_item.count()  # debug stuff
        # TODO: сделать полнотекстовый поиск по имени продукта
        products  =  list_obj.products_item.all().order_by('name')  
        serializer  =  ProductSerializer(products,  many=True)
        return  Response(serializer.data)

    elif  request.method  ==  'POST':
        serializer  =  ProductSerializer(data=request.data)
        if  serializer.is_valid():
            # сохраняем с привязкой к списку
            product_instance  =  serializer.save(list=list_obj) 

            # WebSocket notification
            channel_layer  =  get_channel_layer()
            group_name  =  f"product_list_{list_pk}"  
            product_data  =  ProductSerializer(product_instance).data

            async_to_sync(channel_layer.group_send)(
                group_name,
                {
                    # 'type': 'product.created',  # раньше был баг тут
                    'type':  'product_created',  
                    'product':  product_data    
                }
            )
            print(f"Sent product_created to group {group_name}")  
            
            return  Response(serializer.data,  status=status.HTTP_201_CREATED)
        
        return  Response(serializer.errors,  status=status.HTTP_400_BAD_REQUEST)

# RUD API для продуктов
@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
def product_detail_api(request, product_pk):
    """
    Получение обновление или удаление конкретного продукта.
    Принимает JSON с полями name, price, quantity.
    При PUT обновляет все поля при PATCH - только указанные.
    """

    prod = get_object_or_404(Product, pk=product_pk)
   
    if not prod.list:
         # не должно происходить, но вдруг
         print(f"Warning: Product {product_pk} has no associated list.")
         list_pk = None  # тут надо бы ошибку кинуть наверное
    else:
        list_pk = str(prod.list.id)  

    if request.method == 'GET':
        serializer = ProductSerializer(prod)
        return Response(serializer.data)

    elif request.method in ['PUT', 'PATCH']:
        partial = (request.method == 'PATCH')
        serializer = ProductSerializer(prod, data=request.data, partial=partial)
        if serializer.is_valid():
            updated = serializer.save()  # сохраняем 

            # уведомление через вебсокет
            if list_pk:  # только если есть id списка
                ch_layer = get_channel_layer()
                grp_name = f"product_list_{list_pk}"
                prod_data = ProductSerializer(updated).data  # получаем данные

                # TODO: оптимизировать отправку вебсокет-сообщений
                async_to_sync(ch_layer.group_send)(
                    grp_name,
                    {
                        # 'type': 'product.updated',  # было неправильно 
                        'type': 'product_updated',  
                        'product': prod_data
                    }
                )
                print(f"Sent product_updated to group {grp_name}")  

            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        product_id = str(prod.pk)  # сохраняем ID перед удалением
        prod.delete()  # удаляем из БД

        # вебсокет-уведомление
        if list_pk:  
            channel_layer = get_channel_layer()
            grp_name = f"product_list_{list_pk}"

            async_to_sync(channel_layer.group_send)(
                grp_name,
                {
                    # 'type': 'product.deleted',  # старая версия с точкой
                    'type': 'product_deleted',  
                    'product_id': product_id
                }
            )
            print(f"Sent product_deleted to group {grp_name}")  # логи для отладки

        return Response(status=status.HTTP_204_NO_CONTENT)