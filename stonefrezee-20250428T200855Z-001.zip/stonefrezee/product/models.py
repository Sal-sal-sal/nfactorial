from django.db import models
import uuid
from api.models import Lists  
from django.db import models
import uuid
from api.models import Lists  




class Product(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=90, decimal_places=2) # 10 цифр это 100 млн а 90? странный вопрос
    quantity = models.IntegerField()
    data = models.DateField(auto_now_add=True)
    list = models.ForeignKey(
    Lists,
    on_delete=models.CASCADE,
    related_name= 'products_item',
    null=True, 
    blank=True  
)
    # -----------------------------

    def __str__(self):
        return self.name



