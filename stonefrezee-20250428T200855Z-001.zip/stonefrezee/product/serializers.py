from rest_framework import serializers
from .models import Product


class ProductSerializer(serializers.ModelSerializer):
    list_id = serializers.UUIDField(source='list.id', read_only=True)

    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'quantity', 'data', 'list_id']
        read_only_fields = ['id', 'data', 'list_id']

    def validate_price(self, val):
        if val < 0:
            raise serializers.ValidationError('Цена не может быть отрицательной')
        return val

    def validate_quantity(self, val):
        if val <= 0:
            raise serializers.ValidationError("Количество должно быть положительным")
        return val